| ﻿Model | Metrics (Time RMSE / Type Error Rate) | Metrics (Time RMSE / Type Error Rate) |
| --- | --- | --- |
| Model | Retweet | Taxi |
| RMTPP | -4.1\%/-3.5\% | -2.9\%/-3.7\% |
| NHP | +3.4\%/+3.1\% | +2.6\%/+3.5\% |
| SAHP | +1.3\%/+1.7\% | +1.1\%/+1.2\% |
| THP | +1.3\%/+1.8\% | -1.6\%/+1.5\% |
| AttNHP | +1.2\%/-1.0\% | -1.2\%/-1.2\% |
| ODETPP | -4.0\%/-3.9\% | -4.3\%/-4.5\% |
| FullyNN | -5.0\%/ N.A. | -4.1\%/ N.A. |
| IFTPP | +3.4\%/+3.1\% | +3.9\%/+3.0\% |