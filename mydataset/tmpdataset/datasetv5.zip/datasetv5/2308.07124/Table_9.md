| ﻿Statistic ( ) | CommitPack | The Stack 1.2 | Shared | Shared (%) |
| --- | --- | --- | --- | --- |
| Repositories | 1,934,255 | 18,712,378 | 954,135 | 49.3% |
| Usernames | 825,885 | 6,434,196 | 663,050 | 80.3% |