| ﻿ | HumanEvalPack Python | HumanEvalPack Python | HumanEvalPack Python |  |
| --- | --- | --- | --- | --- |
| Instruction Tuning Dataset ( ) | Fix | Explain | Synthesize | Average |
| Without instruction tuning | 8.7 | 0.0 | 33.6 | 14.1 |
| Self-Instruct (SI) | 23.6 | 0.6 | 43.0 | 22.2 |
| OASST | 23.1 | 34.5 | 46.4 | 34.7 |
| SI + OASST | 24.9 | 28.7 | 46.2 | 33.3 |
| xP3x + OASST | 28.4 | 28.4 | 45.0 | 33.9 |
| CommitPackFT + OASST | 30.4 | 35.1 | 46.2 | 37.2 |
| CommitPackFT + OASST (Formatting) | 31.1 | 28.9 | 45.8 | 35.3 |
| CommitPackFT + OASST (Target loss) | 29.8 | 31.2 | 47.8 | 36.3 |
| CommitPackFT + OASST (Manual) | 27.2 | 29.6 | 45.8 | 34.2 |
| CommitPackFT + xP3x + OASST | 30.9 | 29.5 | 45.9 | 35.4 |
| CommitPackFT + SI + xP3x + OASST | 31.4 | 33.8 | 46.0 | 37.1 |