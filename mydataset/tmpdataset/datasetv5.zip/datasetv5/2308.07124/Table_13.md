| ﻿Model | Python | JavaScript | Java |
| --- | --- | --- | --- |
| SantaCoder | 7.1 | 4.2 | 1.8 |
| SantaCoder + Commit format finetuning | 3.8 | 5.3 | 9.2 |
| SantaCoder + Line diff format finetuning | 9.9 | 9.7 | 10.0 |