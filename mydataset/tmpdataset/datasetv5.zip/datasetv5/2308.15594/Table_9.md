| ﻿ | Comparison | Comparison | Integer division | Integer division | Simplification | Simplification | Addition | Addition | Multiplication | Multiplication |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Base | M= 10⁵ | M= 10⁶ | M= 10⁵ | M= 10⁶ | M= 10⁵ | M= 10⁶ | M= 10⁵ | M= 10⁶ | M= 10⁵ | M= 10⁶ |
| 10 | 100 | 100 | 21.2 | 2.4 | 0.14 | 0.02 | 0 | 0 | 0 | 0 |
| 30 | 99.9 | 100 | 14.2 | 2.2 | 0.21 | 0.02 | 0 | 0 | 0 | 0 |
| 31 | 99.9 | 100 | 14.3 | 2.4 | 0.02 | 0 | 0 | 0 | 0 | 0 |
| 1000 | 100 | 99.9 | 8.8 | 0.7 | 0.09 | 0.01 | 0 | 0 | 0 | 0 |