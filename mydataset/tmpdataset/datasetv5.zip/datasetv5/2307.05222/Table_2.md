| ﻿Models | FID( ) |
| --- | --- |
| unimodal generation models |  |
| GLIDE | 12.24 |
| Make-A-Scene | 11.84 |
| DALL-E 2 | 10.39 |
| SDv1.5 | 9.93 |
| Imagen | 7.27 |
| Parti | 7.23 |
| GILL | 12.20 |
| Emu (ours) | 11.66 |