| ﻿Model | Type | Template |
| --- | --- | --- |
| Emu | Image Captioning | describing the image in detail. the image shows |
| Emu | Image QA | a picture of caption. based on the picture, question short answer: |
| Emu | Image Dialog | a picture of caption. based on the picture, history question short answer: history answer. based on the picture, question short answer: |
| Emu | Video Event understanding QA | a video of caption. a question about the video: question answer: |
| Emu | Video Temporal/Causal QA | a video of caption. a question about the video: question short answer: |
| Emu-I | Image Captioning | [USER]: please provide an accurate and concise description of the given image. [ASSISTANT]: the image depicts a photo of |
| Emu-I | Image QA | [USER]: based on the content of the image and common sense, please provide an accurate answer consisting of only one word or phrase. [ASSISTANT]: the answer is: |
| Emu-I | Image Dialog | [USER]: history question [ASSISTANT]: history answer.<> [USER]: question [ASSISTANT]: |
| Emu-I | Video Event understanding QA | [USER]: based on the content of the video and common sense, please provide an accurate answer consisting of only one word or phrase. question [ASSISTANT]: the answer is: |
| Emu-I | Video Temporal/Causal QA | [USER]: based on the content of the video and common sense, please provide an accurate short answer. question [ASSISTANT]: the answer is: |