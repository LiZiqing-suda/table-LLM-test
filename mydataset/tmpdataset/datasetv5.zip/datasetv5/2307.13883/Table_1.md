| ﻿ | RobustFill | RobustFill | RobustFill | RobustFill | RobustFill | RobustFill | RobustFill | DeepCoder | DeepCoder | DeepCoder | DeepCoder | DeepCoder | DeepCoder | DeepCoder | DeepCoder-Pythonic | DeepCoder-Pythonic | DeepCoder-Pythonic | DeepCoder-Pythonic | DeepCoder-Pythonic | DeepCoder-Pythonic | DeepCoder-Pythonic |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Approach | None | Gen. Tasks | Gen. Tasks | Gen. Tasks | Gen. Tasks | Gen. Tasks | Avg | None | Gen. Tasks | Gen. Tasks | Gen. Tasks | Gen. Tasks | Gen. Tasks | Avg | None | Gen. Tasks | Gen. Tasks | Gen. Tasks | Gen. Tasks | Gen. Tasks | Avg |
| Baseline @1 | 0 4 | 4 | 0 | 1 | 0 | 0 | 1.0 | 23 | 0 | 1 | 0 6 | 0 | 0 5 | 2.4 | 25 | 1 | 0 | 11 | 0 | 0 4 | 3.2 |
| Ablation @1 | 16 | 4 | 0 | 0 | 1 | 6 | 2.2 | 31 | 1 | 2 | 13 | 3 | 0 5 | 4.8 | 30 | 4 | 0 | 12 | 4 | 0 4 | 4.8 |
| ExeDec @1 | 21 | 5 | 0 | 0 | 1 | 6 | 2.4 | 36 | 2 | 3 | 11 | 4 | 10 | 6.0 | 46 | 3 | 3 | 15 | 5 | 16 | 8.4 |
| Baseline @5 | 15 | 1 | 0 | 1 | 2 | 0 5 | 1.8 | 36 | 0 | 1 | 11 | 5 | 13 | 0 6.0 | 34 | 2 | 1 | 15 | 0 5 | 0 8 | 0 6.2 |
| Ablation @5 | 29 | 7 | 1 | 0 | 4 | 0 7 | 3.8 | 51 | 1 | 4 | 18 | 8 | 21 | 10.4 | 42 | 4 | 8 | 19 | 10 | 11 | 10.4 |
| ExeDec @5 | 32 | 5 | 0 | 0 | 5 | 10 | 4.0 | 56 | 2 | 5 | 17 | 8 | 17 | 0 9.8 | 59 | 5 | 9 | 25 | 12 | 30 | 16.2 |