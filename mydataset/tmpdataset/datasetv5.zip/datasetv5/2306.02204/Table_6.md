| ﻿Model | FG-ARI |
| --- | --- |
| SA + Cyclic (No EMA Encoder) | 0.7028 0.03 |
| SA + Cyclic (EMA Encoder) | 0.7838 0.02 |