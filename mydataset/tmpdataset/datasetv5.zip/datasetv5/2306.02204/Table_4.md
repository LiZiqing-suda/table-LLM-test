| ﻿Model | MOVi-C | MOVi-C | MOVi-E | MOVi-E |
| --- | --- | --- | --- | --- |
| Model | FG-ARI | mBO | FG-ARI | mBO |
| DINOSAUR (ViT-B/8) | 68.9 0.4 | 38.0 0.2 | 65.1 1.2 | 33.5 0.1 |
| + Cyclic | 72.4 2.1 | 40.2 0.5 | 69.7 1.6 | 37.2 0.4 |