| ﻿Model | k=1 | k=3 | k=5 | k=10 | k=50 |
| --- | --- | --- | --- | --- | --- |
| DiGress (context) | 47.32 | 68.56 | 73.93 | 78.45 | 80.88 |
| RetroBridge-CE (no context) | 48.71 | 66.84 | 72.33 | 76.08 | 79.38 |
| RetroBridge-CE (context) | 50.74 | 71.50 | 76.58 | 79.50 | 80.58 |
| RetroBridge-VLB (no context) | 47.42 | 69.46 | 75.21 | 79.40 | 83.82 |
| RetroBridge-VLB (context) | 48.92 | 73.04 | 79.44 | 83.74 | 86.31 |