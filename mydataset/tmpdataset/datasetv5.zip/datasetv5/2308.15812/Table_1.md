| ﻿Feedback | H-H | H-AI | # Examples |
| --- | --- | --- | --- |
| Ratings | 1.08 | 0.9 | 1000 |
| Rankings | 62.7% | 60.5% | 500 |