| ﻿Instructions Composition |  |
| --- | --- |
| # of instructions from Dolly | 4K |
| # of instructions from Self-Instruct (User Oriented) | 252 |
| # of instructions from Super-NI | 1K |
| # of generations per instruction | 5 |
| Feedback Composition (GPT-3.5-Turbo) |  |
| # of instances w/ Ratings | 24.6K |
| # of instances w/ Pairwise Rankings | 46.5K |
| Feedback Composition (Humans) |  |
| # of instances w/ Ratings | 4K |
| # of instances w/ Pairwise Rankings | 2K |