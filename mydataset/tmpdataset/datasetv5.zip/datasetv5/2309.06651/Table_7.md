| ﻿Metric | MAE | MAE | MAE | MAE | MAE | MAE | MAE | MAE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Benchmark | AgeDB-DIR | AgeDB-DIR | AgeDB-DIR | AgeDB-DIR | IMDB-WIKI-DIR | IMDB-WIKI-DIR | IMDB-WIKI-DIR | IMDB-WIKI-DIR |
| Methods/Shots | All | Many | Median | Few | All | Many | Median | Few |
| RRT | 7.74 | 6.98 | 8.79 | 11.99 | 7.81 | 7.07 | 14.06 | 25.13 |
| RRT + ConR ( Ours ) | 7.53 | 6.79 | 7.60 | 10.30 | 7.41 | 6.89 | 13.20 | 23.30 |
| Focal-R | 7.64 | 6.68 | 9.22 | 13.00 | 7.97 | 7.12 | 15.14 | 26.96 |
| Focal-R + ConR ( Ours ) | 7.23 | 6.63 | 8.30 | 11.89 | 7.85 | 7.01 | 14.31 | 25.23 |
| Balabced MSE (GAI) | 7.57 | 7.46 | 8.40 | 10.93 | 8.12 | 7.58 | 12.27 | 23.05 |
| Balabced MSE (GAI) + ConR ( Ours ) | 7.22 | 6.71 | 7.99 | 9.88 | 7.84 | 7.20 | 12.09 | 22.20 |
| Ours vs. RRT | 2.71 % | 2.72% | 13.54% | 14.10 % | 5.12 % | 2.55% | 6.12% | 7.28 % |
| Ours vs. Focal-R | 5.37 % | 0.75% | 9.98% | 8.54 % | 1.51 % | 1.54% | 5.48% | 6.42 % |
| Ours vs. Balanced MSE (GAI) | 4.62 % | 10.05% | 4.88% | 9.61 % | 3.45 % | 5.01% | 1.47% | 3.69 % |