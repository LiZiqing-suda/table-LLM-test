| ﻿Benchmark | AgeDB-DIR | AgeDB-DIR | AgeDB-DIR | AgeDB-DIR | IMDB-WIKI-DIR | IMDB-WIKI-DIR | IMDB-WIKI-DIR | IMDB-WIKI-DIR | NYUD2-DIR | NYUD2-DIR | NYUD2-DIR | NYUD2-DIR |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Metric | MAE | MAE | MAE | MAE | MAE | MAE | MAE | MAE | RMSE | RMSE | RMSE | RMSE |
| Method Shot | All | Many | Median | Few | All | Many | Median | Few | All | Many | Median | Few |
| VANILLA | 7.35 | 6.56 | 8.23 | 12.37 | 8.06 | 7.23 | 15.12 | 26.33 | 1.477 | 0.591 | 0.952 | 2.123 |
| + Moco V1 | 7.33 | 6.50 | 8.19 | 11.72 | 7.89 | 7.13 | 14.78 | 26.11 | 1.370 | 0.601 | 0.902 | 1.912 |
| + Moco V2 | 7.47 | 6.21 | 8.75 | 12.75 | 8.12 | 6.99 | 15.02 | 26.01 | 1.404 | 0.632 | 0.978 | 2.207 |
| + ConR | 7.28 | 6.53 | 8.03 | 10.42 | 7.84 | 7.09 | 14.16 | 25.1 5 | 1.304 | 0.682 | 0.889 | 1.885 |
| ConR vs. Moco | 0.68% | -0.46% | 1.96% | 11.10% | 0.63% | 0.56% | 4.20% | 3.68% | 4.82% | -1.63% | 1.44% | 4.41% |