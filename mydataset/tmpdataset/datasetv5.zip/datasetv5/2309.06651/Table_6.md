| ﻿Metrics | MAE | MAE | MAE | MAE |
| --- | --- | --- | --- | --- |
| Methods/Shots | All | Many | Median | Few |
| Contrastive-ConR | 7.69 | 6.12 | 8.73 | 12.42 |
| ConR- | 7.51 | 6.49 | 8.23 | 10.86 |
| ConR- Sim | 7.54 | 6.43 | 8.19 | 10.69 |
| ConR- | 7.52 | 6.55 | 8.11 | 10.51 |
| ConR | 7.48 | 6.53 | 8.03 | 10.42 |