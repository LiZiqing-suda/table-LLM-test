| ﻿Metric | Mean angular error (degrees) | Mean angular error (degrees) | Mean angular error (degrees) | Mean angular error (degrees) |
| --- | --- | --- | --- | --- |
| Method/Shot | All | Many | Median | Few |
| ConR -only (Ours) | 6.16 | 5.73 | 6.85 | 6.17 |
| LDS | 6.48 | 5.93 | 7.28 | 6.83 |
| LDS + ConR (Ours) | 6.08 | 5.76 | 6.81 | 5.98 |
| FDS | 6.71 | 6.01 | 7.50 | 6.64 |
| FDS + ConR (Ours) | 6.32 | 5.69 | 6.56 | 5.65 |
| Balanced MSE (BNI) | 5.73 | 6.34 | 6.41 | 5.36 |
| Balanced MSE (BNI)+ ConR (Ours) | 5.63 | 6.02 | 6.17 | 5.21 |
| Ours vs. LDS | 6.17 % | 2.87% | 6.46% | 12.45 % |
| Ours vs. FDS | 5.81 % | 5.32% | 12.53% | 14.91 % |
| Ours vs. Balanced MSE | 1.75 % | 5.05% | 3.75% | 2.80 % |