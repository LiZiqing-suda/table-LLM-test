| ﻿Finetune Settings | Alpha | HOMO | Mu |
| --- | --- | --- | --- |
| 3D | 0.066 | 23.62 | 0.042 |
| 3D + 2D | 0.060 | 21.47 | 0.037 |