| ﻿ | Directly test on unseen domains | Directly test on unseen domains | Directly test on unseen domains | Directly test on unseen domains | Directly test on unseen domains | Unseen |
| --- | --- | --- | --- | --- | --- | --- |
| Method | bri. | contrast | elastic | pixelate | jpeg | Mean |
| Source | 26.4 | 91.4 | 57.5 | 38.0 | 36.2 | 49.9 |
| Tent | 25.8 | 91.9 | 57.0 | 37.2 | 35.7 | 49.5 |
| CoTTA | 25.3 | 88.1 | 55.7 | 36.4 | 34.6 | 48.0 |
| Ours | 24.6 | 68.2 | 49.8 | 34.7 | 34.1 | 42.3 |