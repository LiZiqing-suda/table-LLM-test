| ﻿Target | Method | Source | Tent | CoTTA | VDP | Ours |
| --- | --- | --- | --- | --- | --- | --- |
| Cifar10C | Mean | 28.2 | 23.5 | 24.6 | 24.1 | 20.7 |
| Cifar10C | Gain | 0.0 | +4.7 | +3.6 | +4.1 | +7.5 |
| Cifar100C | Mean | 35.4 | 32.1 | 34.8 | 35.0 | 27.3 |
| Cifar100C | Gain | 0.0 | +3.3 | +0.7 | +0.4 | +8.1 |