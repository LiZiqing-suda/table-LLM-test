| ﻿ | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Directly test on 10 unseen domains | Unseen |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Method | motion | zoom | snow | frost | fog | brightness | contrast | elastic_trans | pixelate | jpeg | Mean |
| Source | 58.5 | 63.3 | 49.9 | 54.2 | 57.7 | 26.4 | 91.4 | 57.5 | 38.0 | 36.2 | 53.3 |
| Tent | 56.0 | 61.3 | 45.7 | 49.6 | 56.6 | 24.8 | 94.0 | 55.6 | 37.1 | 35.1 | 51.6 |
| CoTTA | 57.3 | 62.1 | 49.1 | 52.0 | 57.1 | 26.4 | 91.9 | 57.1 | 37.6 | 35.3 | 52.6 |
| Ours | 46.4 | 52.7 | 39.8 | 43.7 | 42.2 | 23.5 | 71.5 | 49.6 | 33.9 | 33.3 | 43.7 |