| ﻿ | Directly test on 8 unseen domains | Directly test on 8 unseen domains | Directly test on 8 unseen domains | Directly test on 8 unseen domains | Directly test on 8 unseen domains | Directly test on 8 unseen domains | Directly test on 8 unseen domains | Directly test on 8 unseen domains | Unseen |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Method | snow | frost | fog | brightness | contrast | elastic_trans | pixelate | jpeg | Mean |
| Source | 49.9 | 54.2 | 57.7 | 26.4 | 91.4 | 57.5 | 38.0 | 36.2 | 51.4 |
| Tent | 44.3 | 48.8 | 51.8 | 24.9 | 83.7 | 55.2 | 35.4 | 34.7 | 47.4 |
| CoTTA | 48.8 | 52.2 | 56.7 | 26.1 | 91.1 | 57.0 | 37.3 | 35.3 | 50.6 |
| Ours | 39.6 | 43.7 | 41.7 | 23.7 | 63.7 | 51.7 | 33.3 | 33.6 | 42.3 |