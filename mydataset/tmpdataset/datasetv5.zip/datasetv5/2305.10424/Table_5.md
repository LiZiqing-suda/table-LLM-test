| ﻿ | Threeway | Dynamic | Static | Static |
| --- | --- | --- | --- | --- |
|  | EPE | FG EPE | FG EPE | BG EPE |
| ZeroFlow 1X (Equation 6 , NSFP pseudo-labels)* | 0.084 | 0.217 | 0.023 | 0.011 |
| ZeroFlow 1X (Equation 6 , pseudo-labels) | 0.086 | 0.227 | 0.019 | 0.011 |
| ZeroFlow 1X (NSFP pseudo-labels)* | 0.088 | 0.231 | 0.022 | 0.011 |
| ZeroFlow 1X ( pseudo-labels) | 0.085 | 0.234 | 0.018 | 0.004 |
| ZeroFlow XL 3X | 0.053 | 0.131 | 0.018 | 0.011 |
| ZeroFlow XL 3X (Equation 6 ) | 0.056 | 0.139 | 0.017 | 0.011 |