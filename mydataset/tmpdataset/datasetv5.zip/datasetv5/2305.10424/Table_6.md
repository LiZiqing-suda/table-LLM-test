| ﻿ | Threeway | Dynamic | Static | Static |
| --- | --- | --- | --- | --- |
|  | EPE | FG EPE | FG EPE | BG EPE |
| ZeroFlow 1X* (Ours) | 0.088 | 0.231 | 0.022 | 0.011 |
| FastFlow3D ( ()=1 ) | 0.081 | 0.220 | 0.018 | 0.006 |
| FastFlow3D (Equation 6 ) | 0.081 | 0.224 | 0.018 | 0.002 |
| FastFlow3D * | 0.071 | 0.186 | 0.021 | 0.006 |