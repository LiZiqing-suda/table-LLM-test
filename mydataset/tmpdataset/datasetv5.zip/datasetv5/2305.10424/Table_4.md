| ﻿ | Threeway | Dynamic | Static | Static |
| --- | --- | --- | --- | --- |
|  | EPE | FG EPE | FG EPE | BG EPE |
| ZeroFlow 1X (NSFP pseudo-labels)* | 0.088 | 0.231 | 0.022 | 0.011 |
| ZeroFlow 1X ( pseudo-labels) | 0.085 | 0.234 | 0.018 | 0.004 |
| ZeroFlow 1X (TruncatedChamfer pseudo-labels) | 0.105 | 0.226 | 0.049 | 0.040 |