| ﻿Act. function | Init. scheme | Train Acc. | Test Acc. | Smooth trained weights |
| --- | --- | --- | --- | --- |
| Identity | Weight-tied | 56.5 0.1 | 59.8 0.7 | ✓ |
| Identity | i.i.d. | 56.1 0.3 | 59.6 0.7 |  |
| GELU | Weight-tied | 80.5 0.7 | 79.9 0.2 | ✓ |
| GELU | i.i.d. | 89.8 0.5 | 85.7 0.1 |  |
| ReLU | Weight-tied | 97.4 0.6 | 88.1 0.1 |  |
| ReLU | i.i.d. | 98.4 0.1 | 88.4 0.5 |  |