| ﻿Concept type | Conditions | Procedures | Drugs |
| --- | --- | --- | --- |
| Vocabulary | CCSCM | CCSPROC | ATC-3 |
| Breadth | 4.2 0.4 | 3.8 0.3 | 4.0 0.2 |
| Depth | 4.0 0.3 | 3.9 0.2 | 3.3 0.4 |
| Faithfulness | 4.5 0.3 | 4.7 0.3 | 4.5 0.2 |