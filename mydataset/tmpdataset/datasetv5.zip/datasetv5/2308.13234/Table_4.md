| ﻿Condition | Top-1 (%) | Top-5 (%) |
| --- | --- | --- |
| ideal chance | 0.5 | 2.5 |
| experimental chance | 0.3 | 2.3 |
| NICE | 13.8 | 39.5 |