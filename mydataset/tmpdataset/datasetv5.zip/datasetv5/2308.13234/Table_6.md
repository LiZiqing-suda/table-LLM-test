| ﻿Image Enc | Top-1 (%) | Top-5 (%) | Params. | Memory | Time per subject |
| --- | --- | --- | --- | --- | --- |
| ViT | 7.9 | 18.5 | 88.0 M | 154 G | 130 min |
| ViT* (frozen) | 12.1 | 29.4 | 1.8 M | 8 G | 5 min |
| ResNet | 8.8 | 17.3 | 25.3 M | 112 G | 60 min |
| ResNet* (frozen) | 6.9 | 11.8 | 1.8 M | 8 G | 5 min |