| ﻿Task | Phase Retrieval | Phase Retrieval | HDR | HDR | Deblurring | Deblurring |
| --- | --- | --- | --- | --- | --- | --- |
| Metrics | DPS | RED-diff | DPS | RED-diff | DPS | RED-diff |
| PSNR(dB) | 9.99 | 10.53 | 7.94 | 25.23 | 6.4 | 45.00 |
| SSIM | 0.12 | 0.17 | 0.21 | 0.79 | 0.19 | 0.987 |
| KID | 93.2 | 114.0 | 272.5 | 1.2 | 342.0 | 0.1 |
| LPIPS | 0.66 | 0.6 | 0.72 | 0.1 | 0.73 | 0.0012 |
| top-1 | 1.5 | 7.2 | 4.0 | 68.5 | 6.4 | 75.4 |