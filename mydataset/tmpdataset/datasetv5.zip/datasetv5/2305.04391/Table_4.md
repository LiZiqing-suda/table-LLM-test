| ﻿Anatomy | Brain | Knee | Knee | time |
| --- | --- | --- | --- | --- |
| Sampler | R=4 | R=12 | R=16 | (sec/iter) |
| CSGM | 36.3 | 31.4 | 31.8 | 0.344 |
| RED-diff | 37.1 | 33.2 | 32.7 | 0.114 |