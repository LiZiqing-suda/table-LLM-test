| ﻿ | Components | ETH3D | C-ETH3D |
| --- | --- | --- | --- |
|  | Components | AEPE | AEPE |
| (I) | Conditional denoising diff. | 3.44 | 26.89 |
| (II) | (I) w/o local cost | 4.26 | 32.07 |
| (III) | (I) w/o init flow | 10.28 | 80.81 |
| (IV) | (I) + Flow upsampling diff. (DiffMatch) | 3.12 | 26.45 |