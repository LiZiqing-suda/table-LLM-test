| ﻿Learning schemes | HPatches | ETH3D |
| --- | --- | --- |
| Learning schemes | AEPE | AEPE |
| DiffMatch w/o diffusion | 23.34 | 3.96 |
| DiffMatch | 18.82 | 3.12 |