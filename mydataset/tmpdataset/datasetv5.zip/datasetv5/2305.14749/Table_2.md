| ﻿ |  | ViennaRNA | FARNA | RDesign | Rosetta | gRNAde (single-state) | gRNAde (single-state) | gRNAde (single-state) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| PDB ID | Description | Recovery | Recovery | Recovery | Recovery | Recovery | Perplexity | 2D self-cons. |
| 1CSL | RRE high affinity site | 0.25 | 0.20 | 0.4455 | 0.44 | 0.5719 | 1.2812 | 0.8644 |
| 1ET4 | Vitamin B12 binding RNA aptamer | 0.25 | 0.34 | 0.3929 | 0.44 | 0.6250 | 1.3457 | -0.0135 |
| 1F27 | Biotin-binding RNA pseudoknot | 0.30 | 0.36 | 0.3013 | 0.37 | 0.3437 | 1.6203 | 0.4523 |
| 1L2X | Viral RNA pseudoknot | 0.24 | 0.45 | 0.3727 | 0.48 | 0.4721 | 1.3181 | 0.5692 |
| 1LNT | RNA internal loop of SRP | 0.33 | 0.27 | 0.5556 | 0.53 | 0.5843 | 1.4337 | 0.1379 |
| 1Q9A | Sarcin/ricin domain from E.coli 23S rRNA | 0.27 | 0.40 | 0.4417 | 0.41 | 0.5044 | 1.3411 | 0.0597 |
| 4FE5 | Guanine riboswitch aptamer | 0.29 | 0.28 | 0.4112 | 0.36 | 0.5300 | 1.3824 | 0.9116 |
| 1X9C | All-RNA hairpin ribozyme | 0.26 | 0.31 | 0.3967 | 0.50 | 0.5000 | 1.3905 | 0.6630 |
| 1XPE | HIV-1 B RNA dimerization initiation site | 0.27 | 0.24 | 0.3834 | 0.40 | 0.7037 | 1.2177 | 0.7768 |
| 2GCS | Pre-cleavage state of glmS ribozyme | 0.25 | 0.26 | 0.4518 | 0.44 | 0.5078 | 1.3053 | 0.4062 |
| 2GDI | Thiamine pyrophosphate-specific riboswitch | 0.25 | 0.38 | 0.3523 | 0.48 | 0.6500 | 1.2363 | -0.0251 |
| 2OEU | Junctionless hairpin ribozyme | 0.23 | 0.30 | 0.5000 | 0.37 | 0.9519 | 1.0913 | 0.7768 |
| 2R8S | Tetrahymena ribozyme P4-P6 domain | 0.27 | 0.36 | 0.5641 | 0.53 | 0.5689 | 1.1881 | 0.7281 |
| 354D | Loop E from E. coli 5S rRNA | 0.28 | 0.35 | 0.4458 | 0.55 | 0.4410 | 1.4938 | 0.0430 |
| 354D | Overall recovery: | 0.27 | 0.32 | 0.4296 | 0.45 | 0.5682 |  |  |