| ﻿Model | GLUE (Single-Task) | GLUE (Single-Task) | GLUE (Single-Task) | GLUE (Single-Task) | GLUE (Single-Task) | GLUE (Single-Task) | GLUE (Single-Task) | GLUE (Single-Task) | GLUE (Single-Task) | SQuAD 2.0 | SQuAD 2.0 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model | MNLI-(m/mm) | QQP | QNLI | SST-2 | CoLA | RTE | MRPC | STS-B | AVG | EM | F1 |
| base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) | base setting: Pretrained on Wikipedia & Book Corpus ( 16 GB) |
| BERT | 84.5/- | 91.3 | 91.7 | 93.2 | 58.9 | 68.6 | 87.3 | 89.5 | 83.1 | 73.7 | 76.3 |
| ALBERT | 81.6/- | – | – | 90.3 | – | – | – | – | – | 77.1 | 80.0 |
| UniLMv2 | 86.1/86.1 | – | – | 93.2 | – | – | – | – | – | 80.9 | 83.6 |
| TUPE | 86.2/86.2 | 91.3 | 92.2 | 93.3 | 63.6 | 73.6 | 89.9 | 89.2 | 84.9 | – | – |
| RoBERTa | 84.7/- | – | – | 92.7 | – | – | – | – | – | – | 79.7 |
| RoBERTa (Ours) | 85.9/85.8 | 91.6 | 92.3 | 93.7 | 64.3 | 75.5 | 88.7 | 89.5 | 85.2 | 78.3 | 81.5 |
| MAE-LM | 87.2/87.1 | 91.6 | 92.9 | 93.8 | 63.1 | 79.1 | 90.2 | 90.9 | 86.1 | 81.1 | 84.1 |
| base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) | base++ setting: Pretrained on larger pretraining corpora ( 160 GB) |
| ALBERT | 82.4/- | – | – | 92.8 | – | – | – | – | – | 76.3 | 79.1 |
| RoBERTa | 87.6/- | 91.9 | 92.8 | 94.8 | 63.6 | 78.7 | 90.2 | 91.2 | 86.4 | 80.5 | 83.7 |
| UniLMv2 | 88.5/- | 91.7 | 93.5 | 95.1 | 65.2 | 81.3 | 91.8 | 91.0 | 87.1 | 83.3 | 86.1 |
| MAE-LM | 89.1 / 89.1 | 91.7 | 93.8 | 95.1 | 65.9 | 85.2 | 90.2 | 91.6 | 87.8 | 83.5 | 86.5 |