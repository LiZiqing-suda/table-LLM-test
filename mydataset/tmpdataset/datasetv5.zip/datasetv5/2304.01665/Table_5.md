| ﻿Model | Layers | Heads | Vocabulary Size | Window Size | Hidden Size | MLP Hidden Size | # Parameters | Compared to GPT-3 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Pariity | 4 | 1 | 4 | 40 | 132 | 1959 | 2.2M | 1/100,000 |
| Reverse | 4 | 1 | 28 | 40 | 297 | 1640 | 4.3M | 1/50,000 |
| Last Letter | 3 | 1 | 28 | 16 | 103 | 32 | 62.6K | 1/3,000,000 |
| Copy | 1 | 1 | 28 | 16 | 69 | 26 | 8.8K | 1/20,000,000 |
| Add_in_the_same_position | 7 | 1 | 13 | 40 | 535 | 6422 | 51.8M | 1/3000 |
| Add_Carry | 3 | 1 | 122 | 40 | 130 | 52 | 117K | 1/1,500,000 |
| Sub_in_the_same_position | 7 | 1 | 13 | 40 | 535 | 6422 | 51.8M | 1/3000 |
| Sub_Carry | 3 | 1 | 122 | 40 | 130 | 52 | 117K | 1/1,500,000 |