| ﻿Method | Eval Sim | Eval Sim | Eval Noisy Sim | Eval Noisy Sim |
| --- | --- | --- | --- | --- |
| Method | Succ | SPL | Succ | SPL |
| (c.1) Set to zero | 90.3 | 74.5 | 85.1 | 64.8 |
| (c.2) Set to last waypoint | 88.6 | 74.2 | 81.4 | 63.0 |
| (c.3) Always continue | 94.2 | 80.1 | 89.6 | 74.0 |