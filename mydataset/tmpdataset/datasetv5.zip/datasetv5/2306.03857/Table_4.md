| ﻿Method | Noise | Succ. | SPL |
| --- | --- | --- | --- |
| Class. | no | 95.7 | 89.9 |
| Ours (e) | no | 95.5 | 80.3 |
| Class. | yes | 27.9 | 16.3 |
| Ours (e) | yes | 90.9 | 73.3 |