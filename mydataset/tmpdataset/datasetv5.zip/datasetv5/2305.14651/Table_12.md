| ﻿Models | EN-FR | EN-FR | EN-DE | EN-DE | DBPedia-WikiData | DBPedia-WikiData | DBPedia-Yago | DBPedia-Yago |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Models | Hits@1 | MRR | Hits@1 | MRR | Hits@1 | MRR | Hits@1 | MRR |
| SEA | .225 | .314 | .341 | .421 | .291 | .378 | .490 | .578 |
| NeoEA (SEA) | .254 | .345 | .364 | .446 | . 325 | .416 | .569 | .651 |
| GEEA (SEA) | .269 | .355 | .377 | .459 | .349 | .436 | .597 | .685 |