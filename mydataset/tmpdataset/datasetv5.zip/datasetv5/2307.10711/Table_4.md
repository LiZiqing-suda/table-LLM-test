| ﻿Prompt | DreamBooth | Text-Inv | AdjointDPM |
| --- | --- | --- | --- |
| Airplane | 21.98 | 24.44 | 27.34 |
| Clock | 28.23 | 26.74 | 30.00 |
| House | 25.40 | 25.91 | 29.03 |
| Cat | 25.90 | 22.30 | 26.83 |
| Apples | 28.10 | 24.06 | 28.59 |