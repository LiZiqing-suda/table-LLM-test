| ﻿Ablation | Trained | Post training | Throughput |
| --- | --- | --- | --- |
| Ablation | from scratch | removal | ratio |
| HAT block | -0.24% | -1.49% | 1.08 |
| CT attention | -0.13% | -3.85% | 1.00 |
| Attention Bias | -0.31% | -8.90% | 1.00 |
| CT propagation | -0.16% | - | 0.93 |
| 1D pos bias | -0.07% | -24.85% | 1.00 |
| CT initialization | -0.05% | -0.48% | 1.00 |
| Window 14 14 | +0.10% | - | 0.90 |