| ﻿Benchmark | Benchmark | Dynamic Interaction? | Realistic Environment? | Diverse Human Tasks? | Functional Correctness? |
| --- | --- | --- | --- | --- | --- |
| Mind2Web |  | ✗ | ✓ | ✓ | ✗ |
| Form/QAWoB |  | ✗ | ✓ | ✓ | ✗ |
| MiniWoB++ |  | ✓ | ✗ | ✗ | ✓ |
| Webshop |  | ✓ | ✗ | ✗ | ✓ |
| ALFRED |  | ✓ | ✗ | ✗ | ✓ |
| VirtualHome |  | ✗ | ✗ | ✓ | ✗ |
| AndroidEnv |  | ✓ | ✓ | ✗ | ✗ |
| WebArena | WebArena | ✓ | ✓ | ✓ | ✓ |