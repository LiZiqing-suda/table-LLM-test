| ﻿Data Sampling | Overall | 1-digit | 2-digit | Carry-0 | Carry-1 | Carry-2 | Carry-3 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Random | 97.74 | 98.00 | 96.20 | 95.88 | 98.61 | 98.74 | 94.98 |
| Balanced Digits | 98.13 | 100.00 | 99.70 | 98.87 | 98.64 | 98.13 | 95.93 |
| Balanced Carry-Ons | 98.29 | 100.00 | 99.70 | 98.38 | 97.56 | 99.02 | 98.22 |