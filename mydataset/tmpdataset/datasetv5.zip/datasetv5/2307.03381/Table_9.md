| ﻿Vanilla | Zero-pad | ‘$’-Wrapped |
| --- | --- | --- |
| 88.17% | 97.74% | 97.76% |