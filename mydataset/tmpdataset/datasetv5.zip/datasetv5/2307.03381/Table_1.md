| ﻿ | No Exclusion | No Exclusion | Excluding 100 numbers | Excluding 100 numbers | Excluding 200 numbers | Excluding 200 numbers | Excluding 500 numbers | Excluding 500 numbers |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Plain | Rev | Plain | Rev | Plain | Rev | Plain | Rev |
| Overall Accuracy | 87.18% | 99.97% | 87.94% | 100.00% | 87.24% | 99.99% | 88.15% | 99.99% |
| Exclusion Accuracy | - | - | 92.55% | 100.00% | 92.15% | 99.95% | 90.85% | 100% |