| ﻿ | Plain | Reverse | Simplified Scratchpad | Detailed Scratchpad |
| --- | --- | --- | --- | --- |
| Prompt | 8 | 9 | 23 | 23 |
| Completion | 5 | 6 | 41 | 258 |
| Total | 13 | 15 | 64 | 281 |