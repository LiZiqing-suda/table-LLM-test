| ﻿Excluded position | Input format | Overall Acc | “5” in the 1st (LSB) digit | “5” in the 2nd digit | “5” in the 3rd (MSB) digit |
| --- | --- | --- | --- | --- | --- |
| No exclusion | Plain | 87.18% | 87.50% | 88.65% | 91.80% |
| No exclusion | Reverse | 99.97% | 99.90% | 99.95% | 100% |
| 1st (LSB) digit | Plain | 85.05% | 76.70% | 85.80% | 88.35% |
| 1st (LSB) digit | Reverse | 93.31% | 66% | 94.80% | 94.45% |
| 2nd digit | Plain | 85.44% | 84.55% | 78.50% | 90.15% |
| 2nd digit | Reverse | 98.85% | 98.85% | 94.20% | 99.50% |
| 3rd (MSB) digit | Plain | 85.70% | 85.35% | 87.35% | 83.45% |
| 3rd (MSB) digit | Reverse | 97.18% | 97.25% | 97.35% | 85.45% |