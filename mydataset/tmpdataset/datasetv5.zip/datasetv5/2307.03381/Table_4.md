| ﻿ | Trained on individual task | Trained jointly on all 5 tasks | Trained jointly on all 5 tasks | Trained jointly on all 5 tasks | Trained jointly on all 5 tasks | Trained jointly on all 5 tasks | Trained jointly on all 5 tasks | Trained jointly on all 5 tasks |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Trained on individual task | Zero-shot | Few-shot exemplar format | Few-shot exemplar format | Few-shot exemplar format | Few-shot exemplar format | Few-shot exemplar format | Few-shot exemplar format |
|  | Trained on individual task | Zero-shot | + | – |  | sin | sqrt | text |
| + | 84.06 | 87.96 | 96.45 | 96.90 | 96.92 | 97.06 | 97.01 | 88.71 |
| – | 79.97 | 72.83 | 81.28 | 79.59 | 81.39 | 81.84 | 81.74 | 68.91 |
| – | 4.58 | 14.28 | 18.86 | 18.96 | 15.43 | 19.20 | 19.59 | 15.48 |
| sin | 35.03 | 34.74 | 34.35 | 34.31 | 34.34 | 32.64 | 33.42 | 33.96 |
| sqrt | 19.85 | 27.37 | 26.65 | 26.74 | 26.70 | 25.60 | 25.61 | 26.02 |