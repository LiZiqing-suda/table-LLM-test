| ﻿Perturbation Type | Random | Random | Precise | Precise |
| --- | --- | --- | --- | --- |
| Perturbation Type | Plain | Reverse | Plain | Reverse |
| Exact Acc | 49.88% | 81.26% | 99.85% | 90.47% |
| Relaxed Acc | 61.55% | 100% | 100% | 100% |