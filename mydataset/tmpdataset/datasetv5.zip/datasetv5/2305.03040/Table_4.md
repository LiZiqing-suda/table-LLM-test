| ﻿Architecture | FID | KID |
| --- | --- | --- |
| CIPS-2D | 148.09 | 13.38 |
| StyleGAN2 | 103.62 | 7.89 |
| CIPS-UV (ours) | 41.79 | 2.95 |