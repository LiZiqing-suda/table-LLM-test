| ﻿Method | Mapping Direction | GT Geometry | Proxyless Surface | Smootheness | FID | KID |
| --- | --- | --- | --- | --- | --- | --- |
| (a) (base) | UV Surface |  | ✓ | ✓ | 41.79 | 2.95 |
| (b) | UV Surface | ✓ |  | ✓ | 61.81 | 4.08 |
| (c) | UV Surface | ✓ | ✓ |  | 79.43 | 6.16 |
| (d) | Surface UV | ✓ | ✓ |  | 139.19 | 12.92 |