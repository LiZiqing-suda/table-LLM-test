| ﻿ | GPT-4 | GPT-4 | GPT-4 | GPT-3.5 | GPT-3.5 | GPT-3.5 |
| --- | --- | --- | --- | --- | --- | --- |
| Method | Success Rate | Accuracy |  | Success Rate | Accuracy |  |
| Strict Eval.: ChatGPT-Cheat? | 0/14 | 0.00% |  | 11/14 | 78.57% |  |
| Lenient Eval.: ChatGPT-Cheat? | 9/14 | 64.29% |  | 13/14 | 92.86% |  |
| Algorithm 1: BLEURT | 11/14 | 78.57% |  | 9/14 | 64.29% |  |
| Algorithm 1: ROUGE-L | 13/14 | 92.86% |  | 7/14 | 50.00% |  |
| Algorithm 2: GPT-4 ICL | 14/14 | 100.00% |  | 13/14 | 92.86% |  |