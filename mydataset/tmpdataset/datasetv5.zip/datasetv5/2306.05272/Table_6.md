| ﻿ | CIFAR-10 | CIFAR-10 | CIFAR-20 | CIFAR-20 | CIFAR-100 | CIFAR-100 | ImageNet-1k | ImageNet-1k |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Initialization | ACC | NMI | ACC | NMI | ACC | NMI | ACC | NMI |
| Random | 87.6 | 90.6 | 57.4 | 69.9 | 67.9 | 78.3 | 63.7 | 84.7 |
| Diversified | 97.4 | 93.6 | 64.2 | 72.5 | 74.0 | 81.8 | 66.2 | 86.8 |