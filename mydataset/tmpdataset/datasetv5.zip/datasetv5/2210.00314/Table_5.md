| ﻿(a) Pooling | Acc. |
| --- | --- |
| Graph Pooling | 79.9 |
| Random Sampling | 55.8 |
| K-Means | 73.9 |
| K-Medoids | 72.3 |
| FINCH † | 63.3 |
| Token Pooling † | 75.8 |
| CTM † | 72.2 |
| ToMe † | 78.1 |