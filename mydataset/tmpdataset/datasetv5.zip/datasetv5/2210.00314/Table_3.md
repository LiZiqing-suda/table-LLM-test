| ﻿a) self-supervised on COCO | a) self-supervised on COCO | a) self-supervised on COCO | a) self-supervised on COCO | a) self-supervised on COCO |
| --- | --- | --- | --- | --- |
| test on PASCAL-VOC | before tuning | before tuning | after tuning | after tuning |
| ViT-S | 30.9 | 16.1 | 65.8 | 40.7 |
| ViT-S but with superpixels | 32.2 | 21.2 | 66.5 | 46.7 |
| ViT-S but with token pooling | 34.5 | 19.8 | 67.2 | 41.9 |
| CAST-S | 38.4 | 27.0 | 67.6 | 48.1 |