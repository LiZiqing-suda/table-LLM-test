| ﻿ | Log-likelihood | KL | AU |
| --- | --- | --- | --- |
| Learnable {} | -744.99 | 9.54 | 69\% |
| Unlearnable {} | -743.63 | 9.80 | 100\% |