| ﻿Method | Box Inpainting | Box Inpainting | Box Inpainting |
| --- | --- | --- | --- |
| Method | LPIPS | PSNR | SSIM |
| DPS | 0.127 | 22.85 | 0.861 |
| DDRM | 0.120 | 24.33 | 0.860 |
| DMPS | 0.233 | 22.01 | 0.803 |
| Latent-DPS | 0.199 | 23.14 | 0.784 |
| PSLD-LDM | 0.201 | 23.99 | 0.787 |
| ReSample (Ours) | 0.093 | 24.67 | 0.892 |