| ﻿Model type | Training Time | Training Memory | FID |
| --- | --- | --- | --- |
| LDM (Ours) | 133 mins | 7772MB | 100.48 |
| DDPM | 229 mins | 10417MB | 119.50 |