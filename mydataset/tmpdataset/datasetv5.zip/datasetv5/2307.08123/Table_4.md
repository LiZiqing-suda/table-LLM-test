| ﻿Model | Algorithm | Model Only | Memory Increment | Total |
| --- | --- | --- | --- | --- |
| DDPM | DPS | 1953MB | +3416MB (175%) | 5369MB |
| DDPM | MCG |  | +3421MB (175%) | 5374MB |
| DDPM | DMPS |  | +5215MB (267 %) | 7168MB |
| DDPM | DDRM |  | +18833MB (964 %) | 20786MB |
| LDM | PSLD | 3969MB | +5516MB (140%) | 9485MB |
| LDM | ReSample |  | +1040MB (26.2%) | 5009MB |