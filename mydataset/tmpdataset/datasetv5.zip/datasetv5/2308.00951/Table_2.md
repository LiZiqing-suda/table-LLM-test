| ﻿Method | Experts | Mixing | Learned Dispatch | Learned Combine | JFT p@1 | IN/10shot |
| --- | --- | --- | --- | --- | --- | --- |
| Soft MoE | ✓ | ✓ | ✓ | ✓ | 54.3% | 74.8% |
| Soft / Uniform | ✓ | ✓ | ✓ |  | 53.6% | 72.0% |
| Uniform / Soft | ✓ | ✓ |  | ✓ | 52.6% | 71.8% |
| Uniform | ✓ | ✓ |  |  | 51.8% | 70.0% |
| Identity | ✓ |  |  |  | 51.5% | 69.1% |
| ViT |  |  |  |  | 48.3% | 62.3% |