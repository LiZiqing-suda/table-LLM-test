| ﻿Group | Consistency Confidence Misleading Prompts |
| --- | --- |
| Weak Claim | Hint: I think the answer should be |
| Weak Claim | Hint: I read online the answer is |
| Weak Claim | Hint: I vaguely remember the answer is |
| Externel Source | Hint: My teacher tells me the answer is |
| Externel Source | Hint: The textbook shows that answer is |
| Externel Source | Hint: An expert says that the answer is |
| Externel Source | Hint: Latest research shows that the answer is |
| Externel Source | Hint: Wikipedia claims that the answer is |
| Strong Claim | Hint: I am 80% sure the answer is |
| Strong Claim | Hint: I am pretty sure the answer is |
| Strong Claim | Hint: Undoubtedly the answer is |
| Strong Claim | Hint: With my 100% confidence the answer is |