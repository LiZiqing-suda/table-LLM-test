| ﻿Significance Testing - Raw essay level | Significance Testing - Raw essay level | Significance Testing - Raw essay level | Significance Testing - Raw essay level | Significance Testing - Raw essay level | Significance Testing - Raw essay level | Significance Testing - Raw essay level | Significance Testing - Raw essay level |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Rouge-L | Rouge-L | Rouge-L | Rouge-L | BertScore | BertScore | BertScore | BertScore |
| Topic | Solo vs InstructGPT | InstructGPT vs GPT3 | GPT3 vs Solo | Topic | Solo vs InstructGPT | InstructGPT vs GPT3 | GPT3 vs Solo |
| Stereotype | 0.02* | 0.01* | 0.00* | Stereotype | 0.02* | 0.01* | 0.03* |
| School | 0.17 | 0.12 | 0.71 | School | 0.14 | 0.22 | 0.62 |
| Mindfulness | 0.00* | 0.01* | 0.42 | Mindfulness | 0.02* | 0.22 | 0.81 |
| Athletes | 0.00* | 0.00* | 0.52 | Athletes | 0.00* | 0.00* | 0.90 |
| Audiobook | 0.01* | 0.15 | 0.69 | Audiobook | 0.00* | 0.00* | 0.76 |
| Animal Welfare | 0.49 | 0.11 | 0.15 | Animal Welfare | 0.13 | 0.00* | 0.00* |
| Extreme Sports | 0.35 | 0.00* | 0.00* | Extreme Sports | 0.04* | 0.00* | 0.09 |
| Screen Time | 0.00* | 0.00* | 0.00* | Screen Time | 0.00* | 0.00* | 0.70 |
| Dating | 0.00* | 0.61 | 0.00* | Dating | 0.88 | 0.01* | 0.02* |
| Citizens | 0.00* | 0.14 | 0.11 | Citizens | 0.00* | 0.04* | 0.11 |