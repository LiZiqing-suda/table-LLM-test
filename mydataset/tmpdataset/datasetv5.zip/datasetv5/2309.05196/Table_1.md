| ﻿Model | # Queries | Acceptance Rate (%) | Model-Written Percentage | Word Count |
| --- | --- | --- | --- | --- |
| InstructGPT | 9.15 | 70.49 | 32.45 | 368.39 |
| GPT3 | 9.62 | 71.32 | 35.57 | 380.87 |