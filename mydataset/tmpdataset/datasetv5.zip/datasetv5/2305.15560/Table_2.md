| ﻿Number of samples | FID |
| --- | --- |
| 50000 (original CIFAR10) | 7.87 |
| 20000 (2.5x smaller) | 10.47 |
| 10000 (5x smaller) | 12.51 |
| 5000 (10x smaller) | 18.60 |