| ﻿Model | Accuracy | Precision | Recall | F1 |
| --- | --- | --- | --- | --- |
| PandaLM-7B (with only eval label) | 0.4725 | 0.4505 | 0.4725 | 0.3152 |
| PandaLM-7B | 0.5926 | 0.5728 | 0.5923 | 0.5456 |