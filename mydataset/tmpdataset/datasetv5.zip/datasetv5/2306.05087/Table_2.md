| ﻿Model | Accuracy | Precision | Recall | F1 score |
| --- | --- | --- | --- | --- |
| LLaMA-7B 0-shot (log-likelihood) | 12.11 | 70.23 | 34.52 | 8.77 |
| LLaMA-30B 0-shot (log-likelihood) | 31.43 | 56.48 | 43.12 | 32.83 |
| LLaMA-7B 5-shot (log-likelihood) | 24.82 | 46.99 | 39.79 | 25.43 |
| LLaMA-30B 5-shot (log-likelihood) | 42.24 | 61.99 | 51.76 | 42.93 |
| Vicuna-7B (log-likelihood) | 15.92 | 57.53 | 34.90 | 14.90 |
| Vicuna-13B (log-likelihood) | 35.24 | 57.45 | 43.65 | 36.29 |
| PandaLM-7B | 59.26 | 57.28 | 59.23 | 54.56 |
| PandaLM-7B (log-likelihood) | 59.26 | 59.70 | 63.07 | 55.78 |