| ﻿ | F1 | Precision | Recall | Accuracy |
| --- | --- | --- | --- | --- |
| Random Baselines | Random Baselines | Random Baselines | Random Baselines | Random Baselines |
| Always Majority | 0.0 | 0.0 | 0.0 | 84.77 |
| Random (Proportional) | 13.5 | 12.53 | 14.62 | 71.46 |
| Random (Uniform) | 20.38 | 15.11 | 31.29 | 62.78 |
| BERT-Based Models |  |  |  |  |
| BERT MNLI | 2.82 | 7.23 | 1.75 | 81.61 |
| RoBERTa MNLI | 22.79 | 34.73 | 16.96 | 82.50 |
| DeBERTa MNLI | 14.52 | 14.71 | 14.33 | 74.31 |
| DistilBERT MNLI | 20.70 | 24.12 | 18.13 | 78.85 |
| DistilBART MNLI | 26.74 | 15.92 | 83.63 | 30.23 |
| BART MNLI | 33.38 | 31.59 | 35.38 | 78.50 |
| LLaMa-Based Models |  |  |  |  |
| LLaMa-7B | 26.81 | 15.50 | 99.42 | 17.36 |
| Alpaca-7B | 27.37 | 15.93 | 97.37 | 21.33 |
| GPT-Based Models |  |  |  |  |
| GPT-3 Ada | 0.00 | 0.00 | 0.00 | 84.77 |
| GPT-3 Babbage | 27.45 | 15.96 | 97.95 | 21.15 |
| GPT-3 Curie | 26.43 | 15.23 | 100.00 | 15.23 |
| GPT-3 Davinci | 27.82 | 16.57 | 86.55 | 31.61 |
| GPT-3 Instruct (text-davinci-001) | 17.99 | 11.84 | 37.43 | 48.04 |
| GPT-3 Instruct (text-davinci-002) | 21.87 | 13.46 | 58.19 | 36.69 |
| GPT-3 Instruct (text-davinci-003) | 15.72 | 13.4 | 19.01 | 68.97 |
| GPT-3.5 | 21.69 | 17.79 | 27.78 | 69.46 |
| GPT-4 | 29.08 | 20.92 | 47.66 | 64.60 |