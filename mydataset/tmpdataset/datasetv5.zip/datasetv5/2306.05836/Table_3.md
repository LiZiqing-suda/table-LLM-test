| ﻿ | Overall | Statistics by the Number of Nodes N | Statistics by the Number of Nodes N | Statistics by the Number of Nodes N | Statistics by the Number of Nodes N | Statistics by the Number of Nodes N |
| --- | --- | --- | --- | --- | --- | --- |
|  | Overall | N=2 | N=3 | N=4 | N=5 | N=6 |
| # Samples | 207,972 | 12 | 90 | 720 | 8,520 | 198,630 |
| # Test | 1,162 | 6 | 48 | 72 | 514 | 522 |
| # Dev | 1,076 | 6 | 42 | 72 | 482 | 474 |
| # Train | 205,734 | 0 | 0 | 576 | 7,524 | 197,634 |
| # Tokens/Premise | 424.11 | 31.5 | 52.0 | 104.0 | 212.61 | 434.54 |
| # Tokens/Hypothesis | 10.83 | 10.83 | 10.83 | 10.83 | 10.83 | 10.83 |
| % Positive Labels | 18.57 | 0.00 | 3.33 | 7.50 | 13.01 | 18.85 |
| Vocab Size | 65 | 49 | 53 | 55 | 57 | 61 |