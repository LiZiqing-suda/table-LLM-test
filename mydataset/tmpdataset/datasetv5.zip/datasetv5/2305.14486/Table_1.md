| ﻿Pancreas Point2SSM Ablation | Pancreas Point2SSM Ablation | Pancreas Point2SSM Ablation | Point Accuracy Metrics (mm) | Point Accuracy Metrics (mm) | Point Accuracy Metrics (mm) | SSM Metrics | SSM Metrics | SSM Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Encoder | Attention Module |  | CD | EMD | P2F | Comp. | Gen. | Spec. |
| PointNet | MLP | 0 | 7.35 | 1.78 | 0.833 | 52 | 2.96 | 4.48 |
| PointNet | ATTN | 0 | 3.00 | 1.44 | 0.306 | 27 | 2.24 | 4.67 |
| DGCNN | MLP | 0 | 3.40 | 1.46 | 0.378 | 31 | 2.2 | 4.52 |
| DGCNN | ATTN | 0 | 2.87 | 1.43 | 0.283 | 26 | 2.32 | 4.80 |
| DGCNN | ATTN | 0.1 | 2.72 | 1.42 | 0.283 | 24 | 2.15 | 4.55 |