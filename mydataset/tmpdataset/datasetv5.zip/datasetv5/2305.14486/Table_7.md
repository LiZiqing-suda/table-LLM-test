| ﻿ | Point Accuracy Metrics (mm) | Point Accuracy Metrics (mm) | Point Accuracy Metrics (mm) | SSM Metrics | SSM Metrics | SSM Metrics | SSM Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Batch Size | CD | EMD | P2F | Comp. | Gen. | Spec. | ME |
| 2 | 2.74 | 1.42 | 0.279 | 24 | 2.12 | 4.41 | 3.38 |
| 4 | 2.61 | 1.41 | 0.256 | 23 | 2.22 | 4.61 | 3.22 |
| 6 | 2.64 | 1.41 | 0.270 | 23 | 2.20 | 4.65 | 3.25 |
| 8 | 2.72 | 1.42 | 0.283 | 24 | 2.15 | 4.55 | 3.36 |
| 10 | 2.67 | 1.42 | 0.269 | 24 | 2.14 | 4.66 | 3.32 |
| 12 | 2.71 | 1.42 | 0.280 | 24 | 2.14 | 4.59 | 3.34 |