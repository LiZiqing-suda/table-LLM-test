| ﻿ | Point Accuracy Metrics (mm) | Point Accuracy Metrics (mm) | Point Accuracy Metrics (mm) | SSM Metrics | SSM Metrics | SSM Metrics | SSM Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Model | CD | EMD | P2F | Comp. | Gen. | Spec. | ME |
| PN-AE | 5.22 | 1.82 | 0.897 | 24 | 0.606 | 1.70 | 2.03 |
| DG-AE | 4.90 | 1.79 | 0.836 | 22 | 0.615 | 1.67 | 2.09 |
| CPAE | 8.13 | 1.84 | 0.946 | 117 | 27.4 | 24.7 | 531.42 |
| ISR | 4.66 | 1.69 | 0.714 | 54 | 1.24 | 2.59 | 3.02 |
| DPC | 4.82 | 1.63 | 0.573 | 94 | 1.83 | 3.04 | 4.71 |
| Point2SSM | 2.61 | 1.48 | 0.304 | 34 | 0.879 | 2.06 | 1.98 |