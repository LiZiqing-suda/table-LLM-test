| ﻿Anatomy | Anatomy | Point Accuracy Metrics (mm) | Point Accuracy Metrics (mm) | Point Accuracy Metrics (mm) | SSM Metrics | SSM Metrics | SSM Metrics | SSM Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Train | Test | CD | EMD | P2F | Comp. | Gen. | Spec. | ME |
| Spleen | Spleen | 3.42 | 1.53 | 0.363 | 8 | 4.19 | 6.11 | 3.25 |
| Spleen, Pancreas, Left Atrium | Spleen | 3.33 | 1.54 | 0.310 | 8 | 4.42 | 6.13 | 2.94 |
| Pancreas | Pancreas | 2.72 | 1.42 | 0.283 | 24 | 2.15 | 4.55 | 3.36 |
| Spleen, Pancreas, Left Atrium | Pancreas | 3.10 | 1.44 | 0.352 | 24 | 2.11 | 4.21 | 3.45 |
| Left Atrium | Left Atrium | 2.03 | 1.25 | 0.221 | 20 | 1.90 | 4.13 | 3.45 |
| Spleen, Pancreas, Left Atrium | Left Atrium | 2.15 | 1.25 | 0.258 | 20 | 1.86 | 4.09 | 3.47 |