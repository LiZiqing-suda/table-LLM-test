| ﻿ | Something-Else | Something-Else | CATER: Static Camera | CATER: Static Camera | CATER: Moving Camera | CATER: Moving Camera |
| --- | --- | --- | --- | --- | --- | --- |
| Method | Top 1 | Top 5 | Top 1 | Top 5 | Top 1 | Top 5 |
| SOTA ( c.f . Tables 2 and 3 ) | 56.2 | 81.3 | 79.7 | 95.5 | 59.7 | 90.1 |
| LRR (Joint, Ours) | 61.1 | 85.4 | 80.6 | 97.2 | 73.7 | 95.6 |