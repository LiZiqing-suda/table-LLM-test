| ﻿ | Something-Else (Top 1 ) | Something-Else (Top 1 ) | CATER: Moving Camera (Top 1 ) | CATER: Moving Camera (Top 1 ) |
| --- | --- | --- | --- | --- |
| Method | Train | Test | Train | Test |
| LRR (w/o Surrogate tasks) | 92.6 | 50.1 | 99.4 | 62.7 |
| LRR (Ours) | 87.3 | 62.0 | 89.7 | 80.4 |