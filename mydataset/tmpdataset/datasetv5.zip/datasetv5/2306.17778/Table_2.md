| ﻿ | Base | Base | Compositional | Compositional |
| --- | --- | --- | --- | --- |
| Method | Top-1 | Top-5 | Top-1 | Top-5 |
| STIN + OIE + NL | 78.1 | 94.5 | 56.2 | 81.3 |
| Video-ChatGPT {}* | 52.6 | 75.8 | 38.6 | 67.8 |
| LRR (Ours) | 80.2 | 96.1 | 62.0 | 86.3 |
| LRR (w/o Surrogate tasks) | 71.3 | 89.6 | 50.1 | 70.8 |
| LRR (w/o Two-stream encoder) | 73.2 | 90.4 | 53.6 | 76.1 |