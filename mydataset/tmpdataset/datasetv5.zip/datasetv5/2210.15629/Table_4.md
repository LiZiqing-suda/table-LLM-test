| ﻿ | HULC | SPIL | Diffuser-1D | Diffuser-2D | Ours (HLP only) | Ours (full) |
| --- | --- | --- | --- | --- | --- | --- |
| Training (hrs) ( Lower is Better) | 82 | 86 | 20.8 | 49.2 | 13.3 | 95.3 |
| Inference time (sec) ( ) | 0.005 | 0.005 | 1.11 | 5.02 | 0.333 | 0.336 |
| Avg updates/sec ( ) | .5 | .5 | 4 | 2.1 | 6.25 | 6.25 |
| Model size ( ) | 47.1 M | 54.8 M | 74.7 M | 125.5 M | 20.1 M | 67.8 M |
| Latent dims ( ) | N/A | N/A | 256 | 1024 | 32 | 32 |