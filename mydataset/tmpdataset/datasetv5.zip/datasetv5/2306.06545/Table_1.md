| ﻿ | RS | HOUDINI | LMC | MNTDP-D | PICLE |
| --- | --- | --- | --- | --- | --- |
| Plasticity | ✓ | ✓ | ✓ | ✓ | ✓ |
| Stability | ✓ | ✓ | ✓ | ✓ | ✓ |
| Perceptual Tr | ✓ | ✓ | ✓ | ✓ | ✓ |
| Few-shot Tr | ✓ | ✓ | ✓ | X | ✓ |
| Latent Tr | ✓ | ✓ | ✓ | X | ✓ |
| Scalability | X | X | X | ✓ | ✓ |
| Backward Tr | X | X | X | X | X |