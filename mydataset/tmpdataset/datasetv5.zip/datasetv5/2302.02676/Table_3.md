| ﻿Average win rate (%) | Average win rate (%) | Average win rate (%) |
| --- | --- | --- |
| RLHF | Tie | CoH |
| 30.8 | 24.0 | 45.3 |
| RLHF | Tie | CoH w/o LF |
| 32.1 | 26.5 | 42.4 |
| CoH w/o LF | Tie | CoH |
| 10.6 | 74.3 | 15.1 |