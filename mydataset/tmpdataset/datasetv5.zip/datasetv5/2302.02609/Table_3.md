| ﻿Threshold | # Samples | # Proteins | Sparsity | # Train Proteins | # Valid Proteins | # Test Proteins |
| --- | --- | --- | --- | --- | --- | --- |
| >₅₀ | 87908 | 140 | 0.914 | 92 | 19 | 29 |
| >₁₀₀ | 58823 | 121 | 0.911 | 73 | 24 | 24 |