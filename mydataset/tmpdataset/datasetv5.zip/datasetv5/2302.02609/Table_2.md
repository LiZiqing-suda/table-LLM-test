| ﻿Hyperparameters | DG-15 | TPT-48 | FMoW | ChEMBL-STRING |
| --- | --- | --- | --- | --- |
| Learning Rate | 1e-5 | 2e-3 | 1e-4 | 1e-4 |
| Weight Decay | 5e-4 | 5e-4 | 0 | 0 |
| Batch Size | 10 | 64 | 32 | 30 |
| Epochs | 30 | 40 | 60 | 100 |
| Loss Balanced Coefficient | 0.5 | 0.5 | 0.5 | 0.5 |
| Relation Combining Coefficient | 0.8 | 0.5 | 0.8 | 0.5 |