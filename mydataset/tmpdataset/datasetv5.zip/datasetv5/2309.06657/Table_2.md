| ﻿Preference Pair | Proxy Reward (%) | AutoSxS (%) |
| --- | --- | --- |
| sft-8-sample-first-round-rank | 88.63 | 68.51 |
| sft-8-sample-tournament-rank | 90.69 | 68.57 |
| rso-8-sample-first-round-rank | 92.37 | 71.86 |
| rso-8-sample-tournament-rank | 93.35 | 71.69 |
| sft-64-sample-first-round-rank | 88.91 | 68.84 |
| sft-64-sample-tournament-rank | 91.14 | 71.08 |