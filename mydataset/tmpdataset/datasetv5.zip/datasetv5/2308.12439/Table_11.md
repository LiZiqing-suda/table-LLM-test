| ﻿Number of Clean Samples | Defense | BadNet | Blend |
| --- | --- | --- | --- |
| 100 | ScaleUp | 95.7 | 79.8 |
| 100 | STRIP | 99.2 | 42.5 |
| 100 | BaDExpert | 99.9 | 72.9 |
| 200 | ScaleUp | 95.7 | 79.9 |
| 200 | STRIP | 99.3 | 44.4 |
| 200 | BaDExpert | 100.0 | 91.2 |
| 400 | ScaleUp | 95.7 | 79.9 |
| 400 | STRIP | 99.3 | 44.3 |
| 400 | BaDExpert | 100.0 | 95.1 |
| 2000 | ScaleUp | 95.8 | 80.0 |
| 2000 | STRIP | 99.4 | 44.6 |
| 2000 | BaDExpert | 100.0 | 99.2 |