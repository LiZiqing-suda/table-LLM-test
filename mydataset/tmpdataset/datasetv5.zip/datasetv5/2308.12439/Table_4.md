| ﻿ | ( \% ) | ResNet18 | ResNet18 | ResNet18 | ResNet101 | ResNet101 | ViT-B/16 | ViT-B/16 | ViT-B/16 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | No Attack | BadNet | Blend | No Attack | SRA | No Attack | FT-BadNet | FT-Blend |
| Without Defense | CA | 69.0 | 68.4 | 69.0 | 77.1 | 74.7 | 81.9 | 82.3 | 81.8 |
| Without Defense | ASR | - | 100.0 | 92.2 | - | 100.0 | - | 99.5 | 93.2 |
| BaDExpert | CA | 68.9 | 68.3 | 68.9 | 77.0 | 74.6 | 81.8 | 82.2 | 81.7 |
| BaDExpert | ASR | - | 0.0 | 4.9 | - | 0.0 | - | 0.0 | 0.2 |
| BaDExpert | AUROC | - | 100.0 | 99.9 | - | 100.0 | - | 100.0 | 100.0 |