| ﻿Dataset | Trigger | Victim model | Victim model | Victim model | Suspect model | Suspect model | Suspect model | p-value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dataset |  | Acc | IDWSR | OoDWSR | Acc | IDWSR | OoDWSR |  |
| CIFAR-10 | trojan_wm | 0.9102 | 0.9768 | 0.9566 | 0.8485 | 0.9684 | 0.9547 | 0.0000 |
| CIFAR-10 | trojan_8x8 | 0.9178 | 0.9328 | 0.9423 | 0.8529 | 0.8882 | 0.9051 | 0.0000 |
| CIFAR-100 | trojan_8x8 | 0.6978 | 0.7024 | 0.8761 | 0.5309 | 0.5977 | 0.7040 | 0.0059 |
| CIFAR-100 | l0_inv | 0.6948 | 0.7046 | 0.5834 | 0.5200 | 0.0162 | 0.0622 | 0.0019 |
| GTSRB | smooth | 0.9146 | 0.1329 | 0.9442 | 0.6575 | 0.1386 | 0.9419 | 7.5891e-11 |
| GTSRB | trojan_wm | 0.9089 | 0.7435 | 0.7513 | 0.6379 | 0.7298 | 0.7666 | 2.6070e-21 |