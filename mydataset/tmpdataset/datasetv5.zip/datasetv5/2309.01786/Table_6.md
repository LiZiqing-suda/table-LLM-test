| ﻿Trigger | WP | Victim model | Victim model | Victim model | Suspect model | Suspect model | Suspect model |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Trigger |  | Acc | IDWSR | OoDWSR | Acc | IDWSR | OoDWSR |
| trojan_wm | w/o | 0.9264 | 0.9401 | 0.9490 | 0.9226 | 0.6327 | 0.7305 |
| trojan_wm | w/ | 0.9102 | 0.9768 | 0.9566 | 0.9191 | 0.9769 | 0.9678 |
| trojan_8x8 | w/o | 0.9238 | 0.9263 | 0.9486 | 0.9223 | 0.5304 | 0.8184 |
| trojan_8x8 | w/ | 0.9178 | 0.9328 | 0.9423 | 0.9187 | 0.9533 | 0.9797 |