| ﻿Methods | Family | Kinship | UMLS | WN18RR | FB15k-237 |
| --- | --- | --- | --- | --- | --- |
| EL-NBFNet | 270.3 | 14.0 | 6.7 | 35.6 | 20.1 |
| NBFNet | 269.6 | 13.5 | 6.4 | 34.3 | 19.8 |