| ﻿Methods | SSIM | LPIPS | tLPIPS |
| --- | --- | --- | --- |
| Ours w/ Unidirectional Model | 0.937 | 0.052 | 0.005 |
| Ours | 0.958 | 0.036 | 0.003 |