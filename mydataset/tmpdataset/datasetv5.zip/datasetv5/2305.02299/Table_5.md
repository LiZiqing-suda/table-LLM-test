| ﻿ | SRigL FLOPs | SRigL FLOPs |
| --- | --- | --- |
| sparsity (%) | training ( 1e18 ) | inference ( 1e9 ) |
| 80 | 1.13 | 3.40 |
| 90 | 0.77 | 1.99 |
| 95 | 0.40 | 1.01 |
| 99 | 0.09 | 0.21 |
| 0 | 3.15 | 8.20 |