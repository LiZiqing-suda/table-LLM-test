| ﻿Vocoder | WER | STOI-Net | DNSMOS | LSE-C | LSE-D |
| --- | --- | --- | --- | --- | --- |
| DiffWave | 21.4% | 0.92 | 3.11 | 6.239 | 8.266 |
| HiFi-GAN | 21.9% | 0.93 | 3.19 | 6.308 | 8.166 |