| ﻿Source of text / Lip-Reader | Training dataset split | Intelligibility | Naturalness | Quality | Synchronization |
| --- | --- | --- | --- | --- | --- |
| Ground-Truth Text | train | 3.18 0.28 | 3.29 0.28 | 3.07 0.25 | 3.36 0.26 |
| Ground-Truth Text | train + pretrain | 4.14 0.07 | 4.29 0.09 | 4.18 0.07 | 4.14 0.07 |
| ma | train | 3.21 0.24 | 3.39 0.24 | 3.43 0.25 | 3.46 0.22 |
| ma | train + pretrain | 3.68 0.20 | 3.64 0.19 | 3.79 0.21 | 3.43 0.21 |