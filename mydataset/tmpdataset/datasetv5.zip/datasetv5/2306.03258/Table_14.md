| ﻿Training split | WER | STOI-Net | DNSMOS | LSE-C | LSE-D |
| --- | --- | --- | --- | --- | --- |
| LRS3 | 21.4% | 0.92 | 3.11 | 6.239 | 8.266 |
| LRS3+VoxCeleb2 | 20.6% | 0.93 | 3.20 | 6.312 | 8.160 |