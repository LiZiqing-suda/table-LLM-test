| ﻿No. | 3D-DST | LLM | In-distribution (ID) | In-distribution (ID) | In-distribution (ID) | Out-of-distribution (OOD) | Out-of-distribution (OOD) | Out-of-distribution (OOD) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| No. | (pre-train) | LLM | DeiT-Ti | DeiT-S | ConvNeXt-S | DeiT-Ti | DeiT-S | ConvNeXt-S |
| 1 |  |  | 83.84 ( 0.00) | 84.56 ( 0.00) | 91.34 ( 0.00) | 49.96 ( 0.00) | 49.61 ( 0.00) | 67.19 ( 0.00) |
| 2 | ✓ |  | 86.52 ( 2.68) | 87.82 ( 3.26) | 91.96 ( 0.62) | 54.51 ( 4.55) | 55.95 ( 6.34) | 68.29 ( 1.10) |
| 3 | ✓ | ✓ | 87.36 ( 3.52) | 88.96 ( 4.40) | 92.18 ( 0.84) | 56.12 ( 6.16) | 56.65 ( 7.04) | 69.69 ( 2.50) |