| ﻿Methods | AP2D | AP3D |
| --- | --- | --- |
| CubeRCNN | 41.50 0.00 | 41.65 0.00 |
| w / DST-3D (ours) | 42.34 ( 0.84) | 42.74 ( 1.09) |
| w / DST-3D + camera aug (ours) | 42.86 ( 1.36) | 43.19 ( 1.54) |