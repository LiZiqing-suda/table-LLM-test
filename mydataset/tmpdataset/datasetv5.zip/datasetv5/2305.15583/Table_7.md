| ﻿Sampling Method | 5 steps | 5 steps | 10 steps | 10 steps | 20 steps | 20 steps | 50 steps | 50 steps |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sampling Method | Precision | Recall | Precision | Recall | Precision | Recall | Precision | Recall |
| ADM w/ DDIM | 0.59 | 0.47 | 0.62 | 0.52 | 0.64 | 0.57 | 0.66 | 0.60 |
| ADM w/ TS -DDIM | 0.57 | 0.46 | 0.62 | 0.55 | 0.64 | 0.60 | 0.65 | 0.62 |