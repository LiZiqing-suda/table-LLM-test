| ﻿Sampling Method | 5 steps | 10 steps | 20 steps |
| --- | --- | --- | --- |
| DPM-solver-2 | 32.30 | 10.92 | 4.30 |
| TS -DPM-solver-2 | 31.02(+3.96%) | 9.82(+10.07%) | 4.11(+4.42%) |
| DEIS-order-2- t AB | 24.64 | 5.88 | 4.13 |
| TS -DEIS-order-2- t AB | 22.57(+8.40%) | 5.41(+8.00%) | 3.62(+12.30%) |