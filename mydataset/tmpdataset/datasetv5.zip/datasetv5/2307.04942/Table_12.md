| ﻿ |  | Domain Seperation | Free of Data Leakage | PACS | IWildCam | CelebA | Camelyon17 | CivilComments | Py150 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Centralized adopted methods | Centralized adopted methods | ✗ | ✓ | -0.010 | -0.047 | +0.265 | +0.003 | +0.266 | +0.003 |
| Federated methods | Federated methods | ✓ | ✓ | -0.040 | +0.010 | +0.319 | -0.003 | +0.266 | -0.012 |
| FDG | FedDG | ✓ | ✗ | -0.008 | -0.010 | +0.014 | -0.094 | - | - |
| FDG | FedADG | ✓ | ✓ | -0.013 | +0.060 | +0.152 | -0.017 | - | - |
| FDG | FedSR | ✓ | ✓ | -0.407 | -0.104 | -0.154 | -0.033 | -0.008 | -0.124 |
| FDG | FedGMA | ✓ | ✓ | -0.225 | -0.094 | +0.098 | -0.096 | -0.145 | -0.037 |