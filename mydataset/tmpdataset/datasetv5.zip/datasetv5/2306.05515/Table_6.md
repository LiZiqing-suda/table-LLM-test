| ﻿Layer | Shape | Nonlinearity |
| --- | --- | --- |
| Conv1 | 3 5 5 16 | ReLU |
| MaxPool | 2 2 | – |
| Conv2 | 16 5 5 32 | ReLU |
| MaxPool | 2 2 | flatten |
| FC1 | 800 120 | ReLU |
| FC2 | 120 84 | ReLU |
| FC3 | 84 C | softmax |