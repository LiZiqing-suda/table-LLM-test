| ﻿ | Video Sessions | Video Sessions | Video Sessions | Video Sessions | Video Sessions | Video Sessions | Video Sessions | Video Sessions |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
| Categories | bunny | beauty | bosphorus | bee | jockey | setgo | shake | yacht |
| FPS | - | 120 | 120 | 120 | 120 | 120 | 120 | 120 |
| Length (sec) | - | 5 | 5 | 5 | 5 | 5 | 2.5 | 5 |
| Num. of Frames | 132 | 600 | 600 | 600 | 600 | 600 | 300 | 600 |
| Resolutions | 720 1080 | 1920 1080 | 1920 1080 | 1920 1080 | 1920 1080 | 1920 1080 | 1920 1080 | 1920 1080 |