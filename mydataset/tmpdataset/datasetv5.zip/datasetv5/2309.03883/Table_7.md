| ﻿Model | Baseline | DoLa |
| --- | --- | --- |
| LLaMA-7B | 6.44 | 6.96 |
| LLaMA-13B | 7.06 | 7.98 |
| LLaMA-33B | 6.89 | 7.84 |
| LLaMA-65B | 8.04 | 8.01 |