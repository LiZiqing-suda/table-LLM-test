| ﻿Method | LLaMA-7B | LLaMA-7B | LLaMA-7B | LLaMA-13B | LLaMA-13B | LLaMA-13B |
| --- | --- | --- | --- | --- | --- | --- |
| Method | MC1 | MC2 | MC3 | MC1 | MC2 | MC3 |
| Vanilla | 25.6 | 40.6 | 19.2 | 28.3 | 43.3 | 20.8 |
| DoLa 0-th layer | 31.6 | 61.7 | 30.1 | 28.5 | 62.3 | 30.2 |
| DoLa all layers | 32.0 | 63.9 | 31.2 | 30.5 | 62.3 | 31.0 |
| DoLa | 32.2 | 63.8 | 32.1 | 28.9 | 64.9 | 34.8 |
| Method | LLaMA-33B | LLaMA-33B | LLaMA-33B | LLaMA-65B | LLaMA-65B | LLaMA-65B |
| Method | MC1 | MC2 | MC3 | MC1 | MC2 | MC3 |
| Vanilla | 31.7 | 49.5 | 24.2 | 30.8 | 46.9 | 22.7 |
| DoLa 0-th layer | 31.4 | 61.1 | 31.1 | 31.0 | 63.6 | 31.2 |
| DoLa all layers | 29.1 | 61.5 | 30.7 | 30.5 | 62.0 | 31.7 |
| DoLa | 30.5 | 62.3 | 34.0 | 31.1 | 64.6 | 34.3 |