| ﻿Fast Samplers | Fast Samplers | DPM-Solver-3 | DPM-Solver-3 | DPM-Solver-2 | DPM-Solver-2 | DDIM | DDIM |
| --- | --- | --- | --- | --- | --- | --- | --- |
| NFE | NFE | 20 | 50 | 20 | 50 | 50 | 200 |
| Method | DDPM | 21.91 | 24.48 | 22.21 | 24.80 | 21.80 | 23.16 |
| Method | E-TSDM | 16.97 | 13.52 | 17.28 | 14.14 | 19.34 | 13.71 |