| ﻿Settings | Method | Noise schedule | Noise schedule | Noise schedule | Noise schedule | Noise schedule |
| --- | --- | --- | --- | --- | --- | --- |
| Settings | Method | Linear | Quadratic | Cosine | Cosine-shift | Zero-terminal-SNR |
| Discrete | Baseline | 9.50 | 13.79 | 27.17 | 14.51 | 11.66 |
| Discrete | E-TSDM | 6.62 | 9.69 | 26.08 | 11.20 | 8.58 |
| Continuous | Baseline | 9.53 | 14.26 | 25.65 | 12.80 | 10.89 |
| Continuous | E-TSDM | 6.95 | 9.66 | 16.80 | 9.94 | 8.96 |