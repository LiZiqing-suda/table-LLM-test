| ﻿Algorithm | Maze ( 2¹² ) | Maze ( 2²⁰ ) | Job-shop ( 10¹⁰ ) |
| --- | --- | --- | --- |
| DNC | 68 MB | 68 MB | 73 MB |
| DNC w/o SA | 68 MB | 68 MB | 73 MB |
| MinMax | 68 MB | 68 MB | 73 MB |
| kNN | 68 MB | 252 MB | 373,000 MB |
| LAR | 68 MB | 252 MB | 373,000 MB |
| VAC | 68 MB | 252 MB | 373,000 MB |