| ﻿ | Direction optimality | Separability | Injectivity |
| --- | --- | --- | --- |
| Wasserstein GAN | ✓ | weak |  |
| GAN (Hinge, Saturating, Non-saturating) | ✗ | ✓ |  |
| SAN (Hinge, Saturating, Non-saturating) | ✓ | ✓ |  |