| ﻿Attributes | Value Descriptions |
| --- | --- |
| source | "", "Yandex satellite", "NASA", "Google Maps" |
| geographical feature | "", "island", "ul.", "street" |
| image type | "", "satellite", "aerial", "map" |
| natural phenomenon | "", "hurricane", "earthquake", "deforestation" |
| structure type | "", "residential", "commercial", "fortress" |