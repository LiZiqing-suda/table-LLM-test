| ﻿ | Without | With intervention | With intervention |
| --- | --- | --- | --- |
|  | intervention | ClassAtrr | PureAttr |
| ImageNet | 68.59% | 68.70% | 68.72% |
| ImageNetV2 | 62.10% | 62.31% | 62.32% |
| ImageNet-R | 78.12% | 78.38 % | 78.27% |
| ImageNet-A | 51.17% | 51.39 % | 51.22% |
| ImageNet-Sketch | 49.03% | 49.10% | 49.10% |