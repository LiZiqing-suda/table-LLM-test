| ﻿ | Core ( ) | Spurious ( ) |
| --- | --- | --- |
| no context | 62.8 | 37.2 |
| wrong context | 62.6 | 37.4 |
| random context | 62.3 | 37.7 |
| correct context | 66.3 | 33.7 |