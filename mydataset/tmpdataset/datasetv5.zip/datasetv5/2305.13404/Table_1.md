| ﻿sharpness ( ) | sharpness ( ) | sharpness ( ) | curvature ( ) | curvature ( ) | curvature ( ) |
| --- | --- | --- | --- | --- | --- |
| MNIST | Fashion-MNIST | CIFAR-10 | MNIST | Fashion-MNIST | CIFAR-10 |
| 0.704 | 0.790 | 0.899 | -0.050 | -0.232 | -0.167 |