| ﻿Approach | CIFAR-10 | ImageNet | CelebA |
| --- | --- | --- | --- |
| ADM-IP | 3.25 | 2.72 | 1.31 |
| DDPM | 3.61 | 3.62 | 1.73 |
| DDPM w/ Consistent DM | 3.31 | 3.16 | 1.38 |
| DDPM w/ FP-Diffusion | 3.47 | 3.28 | 1.56 |
| DDPM w/ Our Proposed Regularization | 2.93 | 2.55 | 1.22 |