| ﻿Scorer | Source | Instruction position | Instruction | Accuracy | Accuracy |
| --- | --- | --- | --- | --- | --- |
| Scorer |  |  |  | MultiArith | AQuA |
| Baselines | Baselines | Baselines |  |  |  |
| PaLM 2-L |  | A_begin | Let’s think step by step. | 85.7 | 44.9 |
| PaLM 2-L |  | A_begin | Let’s work this out in a step by step way to be sure we have the right answer. | 72.8 | 48.4 |
| PaLM 2-L |  | A_begin | Let’s solve the problem. | 87.5 | 44.1 |
| PaLM 2-L |  | A_begin | (empty string) | 69.3 | 37.8 |
| text-bison |  | Q_begin | Let’s think step by step. | 92.5 | 31.9 |
| text-bison |  | Q_begin | Let’s work this out in a step by step way to be sure we have the right answer. | 93.7 | 32.3 |
| text-bison |  | Q_begin | Let’s solve the problem. | 85.5 | 29.9 |
| text-bison |  | Q_begin | (empty string) | 82.2 | 33.5 |
| Ours | Ours | Ours |  |  |  |
| PaLM 2-L | PaLM 2-L-IT on GSM8K | A_begin | Take a deep breath and work on this problem step-by-step. | 95.3 | 54.3 |
| text-bison | PaLM 2-L-IT on GSM8K | Q_begin | Let’s work together to solve math word problems! First, we will read and discuss the problem together to make sure we understand it. Then, we will work together to find the solution. I will give you hints and help you work through the problem if you get stuck. | 96.8 | 37.8 |