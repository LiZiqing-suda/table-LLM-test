| ﻿Method/Dataset | Regression (MAE ) | Regression (MAE ) | Regression (MAE ) | Regression (MAE ) | Regression (MAE ) | Regression (MAE ) | Text Generation (BLEU ) | Text Generation (BLEU ) | Text Generation (BLEU ) | Text Generation (BLEU ) | Text Generation (BLEU ) | Text Generation (BLEU ) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Method/Dataset | CG | CA | DS | AD | CB | BL | CG | CA | DS | AD | CB | BL |
| mean/mode | 0.81 | 0.61 | 0.84 | 0.78 | 0.73 | 0.84 | 48 | 62 | 46 | 62 | 65 | 43 |
| Linear Regress | 0.64 | 0.58 | 0.91 | 0.45 | 0.60 | 0.51 | - | - | - | - | - | - |
| GPT-3 | 0.58 | 0.57 | 0.69 | 0.64 | 0.61 | 0.46 | 48 | 66 | 39 | 73 | 71 | 82 |
| UniTabE scratch | 0.49 | 0.56 | 0.83 | 0.69 | 0.72 | 0.38 | 35 | 63 | 28 | 67 | 18 | 75 |
| UniTabE finetune | 0.40 | 0.51 | 0.61 | 0.43 | 0.51 | 0.22 | 59 | 76 | 51 | 80 | 85 | 92 |