| ﻿Method/Drop k | 1 | 2 |
| --- | --- | --- |
| TransTab-LSTM | 7.5 | 11.7 |
| UniTabE scratch | 5.3 | 8.4 |
| UniTabE finetune | 3.5 | 5.8 |