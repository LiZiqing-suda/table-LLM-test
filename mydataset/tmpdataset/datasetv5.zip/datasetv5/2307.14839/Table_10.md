| ﻿Method | Ours | params | convergence step |
| --- | --- | --- | --- |
| Ours(kernelised) | -7644.39 | 4.85M | 103K |
| NN-based MixerFlow | -7665.65 | 11.43M | 195K |