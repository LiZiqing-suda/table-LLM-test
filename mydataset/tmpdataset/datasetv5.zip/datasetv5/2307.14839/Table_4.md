| ﻿Architectures | Architectures | Architectures | Architectures |  |
| --- | --- | --- | --- | --- |
| Dataset | RealNVP | FF-RealNVP (ours) | Glow | FF-Glow (ours) |
| Miniboone | 377K | 117K (69%) | 395K | 141K (64%) |
| Hepmass | 288K | 76K (74%) | 293K | 79K (73%) |
| Gas | 236K | 22K (91%) | 237K | 23K (90%) |
| Power | 228K | 16K (93%) | 228K | 20K (91%) |
| BSDS300 | 458K | 171K (63%) | 497K | 279K (44%) |