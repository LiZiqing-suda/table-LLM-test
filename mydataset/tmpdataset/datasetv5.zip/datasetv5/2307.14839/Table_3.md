| ﻿Dataset | Ours (#params) | FFJORD (#params) |
| --- | --- | --- |
| Miniboone | -27.75 ( 58K ) | -39.92 (821K) |
| Hepmass | -27.90 ( 41K ) | -28.17 (197K) |
| Gas | 0.22 ( 11K ) | -7.50 (279K) |
| Power | -2.91 ( 8K ) | -11.33 (43K) |
| BSDS300 | 121.22 ( 85K ) | 100.32 (3,127K) |