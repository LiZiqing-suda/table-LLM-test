| ﻿Setting | Setting | FPR | FNR | F1 |
| --- | --- | --- | --- | --- |
| Domain: Agent | Key-based Detector | 0.5 | 0.0 | 99.8 |
| Domain: Agent | Network-based Detector | 0.0 | 0.7 | 99.6 |
| Domain: Place | Key-based Detector | 0.0 | 0.5 | 99.7 |
| Domain: Place | Network-based Detector | 0.1 | 2.4 | 98.9 |
| Domain: Species | Key-based Detector | 0.0 | 1.0 | 99.5 |
| Domain: Species | Network-based Detector | 0.0 | 2.8 | 98.3 |