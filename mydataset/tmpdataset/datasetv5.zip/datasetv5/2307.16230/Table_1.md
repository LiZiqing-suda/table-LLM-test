| ﻿Methods / Dataset | Methods / Dataset | Methods / Dataset | C4 | C4 | C4 | Dbpedia Class | Dbpedia Class | Dbpedia Class |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Methods / Dataset | Methods / Dataset | Methods / Dataset | FPR | FNR | F1 | FPR | FNR | F1 |
| GPT2 | Top-K Sample | Key-based | 0.2 | 0.4 | 99.7 | 0.2 | 0.0 | 99.9 |
| GPT2 | Top-K Sample | Network-based (UPV) | 0.2 | 1.1 | 99.3 | 0.6 | 1.4 | 99.0 |
| GPT2 | Beam Search | Key-based | 0.2 | 0.2 | 99.8 | 0.2 | 0.0 | 99.9 |
| GPT2 | Beam Search | Network-based (UPV) | 0.2 | 0.7 | 99.6 | 0.1 | 0.8 | 99.6 |
| OPT 1.3B | Top-K Sample | Key-based | 0.0 | 0.4 | 99.8 | 0.0 | 0.6 | 99.7 |
| OPT 1.3B | Top-K Sample | Network-based | 0.2 | 4.7 | 97.5 | 0.8 | 3.1 | 98.0 |
| OPT 1.3B | Beam Search | Key-based | 0.0 | 0.0 | 100.0 | 0.0 | 0.0 | 100.0 |
| OPT 1.3B | Beam Search | Network-based (UPV) | 0.2 | 0.6 | 99.6 | 0.8 | 0.4 | 99.4 |
| LLaMA 7B | Top-K Sample | Key-based | 0.0 | 1.0 | 99.5 | 0.0 | 3.0 | 98.5 |
| LLaMA 7B | Top-K Sample | Network-based (UPV) | 0.4 | 3.2 | 98.2 | 1.2 | 3.7 | 97.5 |
| LLaMA 7B | Beam Search | Key-based | 0.0 | 0.0 | 100.0 | 0.0 | 0.6 | 99.7 |
| LLaMA 7B | Beam Search | Network-based (UPV) | 0.1 | 0.4 | 99.8 | 0.5 | 0.9 | 99.3 |