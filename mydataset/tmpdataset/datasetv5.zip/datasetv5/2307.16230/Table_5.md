| ﻿Setting | Key-based F1 | Network-based F1 | Ori. BLEU | Wat. BLEU |
| --- | --- | --- | --- | --- |
| EN-FR | 98.7 | 98.1 | 39.3 | 38.5 |
| FR-EN | 99.2 | 98.9 | 37.9 | 34.0 |
| EN-DE | 99.2 | 99.0 | 49.6 | 49.6 |
| DE-EN | 99.4 | 99.1 | 38.5 | 37.9 |