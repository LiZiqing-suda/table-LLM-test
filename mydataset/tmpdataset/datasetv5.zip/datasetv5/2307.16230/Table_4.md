| ﻿Methods / Settings | Methods / Settings | Methods / Settings | No Attack | No Attack | No Attack | Rewrite w. GPT3.5 | Rewrite w. GPT3.5 | Rewrite w. GPT3.5 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Methods / Settings | Methods / Settings | Methods / Settings | FPR | FNR | F1 | FPR | FNR | F1 |
| GPT2 | w. window_size 1 | Key-based | 0.0 | 0.0 | 100.0 | 2.4 | 4.7 | 96.4 |
| GPT2 | w. window_size 1 | Network-based | 0.6 | 0.0 | 99.7 | 6.4 | 1.0 | 96.4 |
| GPT2 | w. window_size 2 | Key-based | 0.0 | 0.0 | 100.0 | 4.6 | 9.3 | 92.8 |
| GPT2 | w. window_size 2 | Network-based | 0.0 | 1.0 | 99.5 | 5.0 | 2.6 | 96.2 |
| OPT 1.3B | w. window_size 1 | Key-based | 0.0 | 0.0 | 100.0 | 6.8 | 8.9 | 92.0 |
| OPT 1.3B | w. window_size 1 | Network-based | 0.0 | 0.0 | 100.0 | 17.4 | 3.4 | 90.3 |
| OPT 1.3B | w. window_size 2 | Key-based | 0.0 | 0.0 | 100.0 | 7.8 | 11.5 | 90.1 |
| OPT 1.3B | w. window_size 2 | Network-based | 0.4 | 1.0 | 99.3 | 4.6 | 11.2 | 91.8 |
| LLaMA 7B | w. window_size 1 | Key-based | 0.0 | 0.0 | 100.0 | 8.4 | 12.5 | 89.0 |
| LLaMA 7B | w. window_size 1 | Network-based | 0.0 | 0.0 | 100.0 | 18.0 | 5.0 | 89.2 |
| LLaMA 7B | w. window_size 2 | Key-based | 0.0 | 0.0 | 100.0 | 11.0 | 13.7 | 87.2 |
| LLaMA 7B | w. window_size 2 | Network-based | 1.8 | 1.0 | 98.6 | 12.4 | 2.6 | 92.9 |