| ﻿Method | MNIST | Imagenette |
| --- | --- | --- |
| DIME | 4.88 | 27.14 |
| Argmax Direct | 6.02 | 43.67 |
| EDDI | 0.39 | - |
| Hard Attn | - | 18.25 |
| CwCF | 28.91 | - |