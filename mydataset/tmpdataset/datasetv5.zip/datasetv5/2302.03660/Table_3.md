| ﻿ |  | General (2D) | Glycine (2D) | Proline (2D) | Pre-Pro (2D) | RNA (7D) |
| --- | --- | --- | --- | --- | --- | --- |
|  | Dataset size (train + val + test) | 138208 | 13283 | 7634 | 6910 | 9478 |
|  | Mixture of Power Spherical | 1.15 0.002 | 2.08 0.009 | 0.27 0.008 | 1.34 0.019 | 4.08 0.368 |
|  | Riemannian Diffusion Model | 1.04 0.012 | 1.97 0.012 | 0.12 0.011 | 1.24 0.004 | -3.70 0.592 |
| 1-8 | Riemannian Flow Matching w / Geodesic | 1.01 0.025 | 1.90 0.055 | 0.15 0.027 | 1.18 0.055 | -5.20 0.067 |